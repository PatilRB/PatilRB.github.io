import * as THREE from 'three';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {slashBundle, tipAt} from './slash.mjs';
const renderer = new THREE.WebGLRenderer({antialias: true});
renderer.setSize(960, 560); document.querySelector('#view').append(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color('#0b1220');
const camera = new THREE.PerspectiveCamera(55, 960/560, .1, 100);
const blade = new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,1.8,8), new THREE.MeshBasicMaterial({color: 0xe6edf7}));
scene.add(blade); scene.add(new THREE.GridHelper(8,16,0x3f526e,0x24324a));
const vfx = new ThreeVfxRenderer({scene, camera, captureDebugTransforms: true});
const fx = vfx.createEffect(slashBundle().effect, {seed: 419, autoStart: false});
let t=0, running=false, emitting=false, last=0, cameraTime=0;
function poseBlade(time){const p=tipAt(time);blade.position.set(p[0]/2,(p[1]+1.2)/2,0);blade.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(p[0],p[1]-1.2,0).normalize());}
function replay(){t=0;running=true;emitting=true;fx.setTransform({position: tipAt(0)});fx.restart();}
document.querySelector('#replay').onclick=replay;
document.querySelector('#drain').onclick=()=>{running=false;emitting=false;fx.play();fx.allowCompletion();};
document.querySelector('#inspect').onclick=()=>{replay();for(let i=1;i<=14;i++){t=i/60;fx.setTransform({position:tipAt(t)});vfx.update(1/60);}poseBlade(t);fx.pause();running=false;emitting=false;};
renderer.setAnimationLoop(ms=>{
  const dt=last?Math.min((ms-last)/1000,.05):0;last=ms;
  if(document.querySelector('#camera').checked) cameraTime+=dt;
  camera.position.set(Math.sin(cameraTime*.7)*3,2.6,6+Math.cos(cameraTime*.7));
  camera.lookAt(0,1.2,0);
  if(running){t+=dt;const p=tipAt(t);poseBlade(t);
    if(emitting && t<=.45) fx.setTransform({position:p});
    else if(emitting){emitting=false;fx.allowCompletion();}
  }
  vfx.update(dt); renderer.render(scene,camera);
  document.querySelector('#status').textContent=`swing ${Math.min(t,.45).toFixed(2)}s | live ${vfx.stats.activeParticles} | visible ${vfx.stats.visibleParticles} | unsupported ${vfx.stats.unsupportedFeatures.length} | emission ${emitting?'on':'off'}`;
});
replay();
