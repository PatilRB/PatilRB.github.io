import { createDefaultParticleEffect, createConstantParticleScalar as scalar } from 'nixie-fx';
import { compileVfxExport, loadVfxExportBundle } from 'nixie-fx/export';

export function slashBundle() {
  const effect = createDefaultParticleEffect('sword-dots', 'Sword tip particle trail');
  effect.targetProfile = 'three-world-3d';
  effect.timeline.duration = 2;
  effect.timeline.loop.enabled = true;
  const e = effect.emitters[0];
  e.id = 'tip'; e.duration = 2; e.loop = true; e.maxParticles = 64;
  e.spawn.shape = 'point'; e.spawn.simulationSpace = 'world';
  e.spawn.rate = 120; e.spawn.rateValue = scalar(120); e.spawn.bursts = [];
  e.initializeParticle.lifetime = scalar(0.32);
  e.initializeParticle.velocity.speed = scalar(0);
  e.initializeParticle.size = scalar(0.065);
  e.billboard.sizeStart = 0.065; e.billboard.sizeEnd = 0.065;
  e.billboard.sizeValue = scalar(0.065);
  e.render.shading = 'unlit'; e.render.blend = 'alpha';
  e.render.depthTest = true; e.render.depthWrite = false;
  e.initializeParticle.color.color = [0.35, 0.8, 1, 0.85];
  e.modules.color = true;
  e.color.gradient.colorStops = [
    {position: 0, color: [0.35, 0.8, 1]}, {position: 1, color: [0.35, 0.8, 1]}
  ];
  e.color.gradient.alphaStops = [{position: 0, alpha: 0.85}, {position: 1, alpha: 0}];
  const compiled = compileVfxExport([{effect, effectPath: 'effects/sword-dots.json'}]);
  const bundle = loadVfxExportBundle({
    manifest: compiled.manifest,
    effectsByPath: Object.fromEntries(compiled.effects.map(item => [item.path, item.effect])),
    assetPaths: []
  }, {requiredBackend: 'three3d', requireEveryAsset: true});
  return {bundle, compiled, effect: bundle.effectsById.get('sword-dots')};
}

export function tipAt(t) {
  const a = -1.15 + Math.min(t / 0.45, 1) * 2.3;
  return [Math.cos(a) * 1.8, 1.2 + Math.sin(a) * 1.8, 0];
}
