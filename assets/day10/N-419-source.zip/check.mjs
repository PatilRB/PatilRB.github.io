import assert from 'node:assert/strict';
import {writeFileSync, mkdirSync} from 'node:fs';
import * as THREE from 'three';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {slashBundle, tipAt} from './slash.mjs';

const {effect, compiled} = slashBundle();
mkdirSync('public/vfx/effects', {recursive: true});
writeFileSync('public/vfx/manifest.json', JSON.stringify(compiled.manifest, null, 2));
for (const item of compiled.effects) writeFileSync(`public/vfx/${item.path}`, JSON.stringify(item.effect, null, 2));
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(55, 1.6, 0.1, 100);
camera.position.set(0, 2, 7); camera.lookAt(0, 1, 0); camera.updateMatrixWorld(true);
const vfx = new ThreeVfxRenderer({scene, camera, captureDebugTransforms: true});
const fx = vfx.createEffect(effect, {seed: 419, autoStart: false});
assert.equal(effect.support.backends.three3d.blockers.length, 0);
fx.setTransform({position: tipAt(0)}); fx.play();
let peak = 0;
for(let frame = 1; frame <= 27; frame++) {
  fx.setTransform({position: tipAt(frame / 60)});
  vfx.update(1 / 60); peak = Math.max(peak, vfx.stats.activeParticles);
}
fx.allowCompletion();
const positions = () => fx.getParticleDebugTransforms().map(p => p.position);
const before = positions();
assert.ok(before.length > 0);
fx.setTransform({position: [8, 8, 8]}); vfx.update(0);
assert.deepEqual(positions(), before, 'old particles must not move with a new origin');
camera.position.set(5, 3, 4); camera.lookAt(0, 1, 0); camera.updateMatrixWorld(true);
vfx.update(0);
assert.deepEqual(positions(), before, 'camera motion must not change particle world positions');
assert.equal(vfx.stats.unsupportedFeatures.length, 0);
for(let frame = 0; frame < 30; frame++) vfx.update(1 / 60);
assert.equal(vfx.stats.activeParticles, 0);
assert.equal(vfx.stats.visibleParticles, 0);
const result = {versions: {nixieFx: '0.1.20', three: '0.185.1'}, fixedStep: '1/60 seconds', swingSeconds: 0.45, lifetimeSeconds: 0.32, peakParticles: peak, sampledBeforeDrain: before.length, movedOriginPreservesOldPositions: true, cameraMotionPreservesWorldPositions: true, particlesAfterHalfSecondDrain: vfx.stats.activeParticles, unsupportedFeatures: vfx.stats.unsupportedFeatures, support: effect.support.backends.three3d, limits: 'Node adapter checks only; not a GPU, framerate, target-device or continuous ribbon test.'};
writeFileSync('./evidence/N-419-runtime.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
vfx.destroy();
