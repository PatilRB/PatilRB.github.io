import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
export function auditLevel(level) {
  if (!level || !Number.isInteger(level.width) || level.width < 1 ||
      !Number.isInteger(level.height) || level.height < 1 || !Array.isArray(level.markers)) {
    throw new Error('Expected positive integer width/height and a markers array');
  }
  const issues = [], seen = new Set();
  for (const marker of level.markers) {
    if (!marker || typeof marker.id !== 'string' || !marker.id.trim() ||
        !Number.isInteger(marker.x) || !Number.isInteger(marker.y)) {
      throw new Error('Each marker needs a nonempty string id and integer x/y');
    }
    if (seen.has(marker.id)) issues.push(`ERROR ${marker.id}: duplicate id`);
    seen.add(marker.id);
    if (marker.x < 0 || marker.x >= level.width || marker.y < 0 || marker.y >= level.height) {
      issues.push(`ERROR ${marker.id}: (${marker.x},${marker.y}) outside ${level.width}x${level.height}`);
    }
  }
  return issues.sort();
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const level = JSON.parse(await readFile(process.argv[2], 'utf8'));
    const issues = auditLevel(level);
    console.log(issues.length ? issues.join('\n') : 'OK: no marker issues');
    process.exitCode = issues.length ? 2 : 0;
  } catch (error) {
    console.error(`INPUT ERROR: ${error.message}`);
    process.exitCode = 1;
  }
}
