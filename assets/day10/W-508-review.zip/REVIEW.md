# W-508 qualified human review

Status: PENDING. No human approval has been supplied or inferred from automated tests.

Scope: read-only JSON level-marker auditor in the published article. Review the synthetic sample and the exact standalone listing before considering any engine/project adoption.

## Review material

- Published article: https://patilrb.github.io/2026/10/19/review-a-level-auditor-with-a-designer.html
- Source: audit-level.mjs
- Reproduction: from the source folder, run `node audit-level.mjs room.json` (expected exit 2 for the intentionally invalid sample), then `node check.mjs` (expected exit 0).
- Existing evidence: W-508-check.json and article-listing-check.json.
- The sample script only reads its input; it does not repair or overwrite level data.

## Human reviewer checklist

- Confirm integer width/height and 0-based marker coordinates match the example contract.
- Check boundary x=width / y=height is out of bounds; zero is allowed; negative and fractional coordinates rejected as documented.
- Check nonempty marker IDs, duplicate IDs, malformed JSON and missing input handling.
- Check deterministic output and exit codes 0 (clean), 2 (issues), 1 (invalid input).
- Confirm the article's standalone listing and downloadable source produce the same output on room.json.
- Assess unexpected input-size/memory limits before applying to a real project; no production size guarantee is claimed.
- Inspect the read-only behavior and report any misleading wording in the article.
- Record the actual review verdict; do not treat these unchecked boxes as approval.

Reviewer name and relevant role: ______
Reviewed source SHA-256: ______
Date: ______
Verdict (approved for this illustrative scope / changes requested): ______
Findings and required changes: ______
