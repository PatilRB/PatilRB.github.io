export class Reward {
 constructor(fixed){this.fixed=fixed;this.claimed=false;this.requests=0;this.open();}
 open(){this.view=this.fixed&&this.claimed?'claimed':'available';}
 close(){this.view='closed';}
 claim(success=true){if(this.view!=='available')return false;this.requests++;this.view='claiming';if(success){this.claimed=true;this.view='claimed';}else this.view='available';return true;}
}
export class Battle {
 constructor(fixed){this.fixed=fixed;this.history=[];this.applications=0;this.seen=new Set();}
 receive(id,accepted=true){if(!accepted)return;if(!this.seen.has(id)){this.applications++;this.seen.add(id);}if(!this.fixed||!this.history.includes(id))this.history.push(id);}
}
export class Inventory {
 constructor(fixed){this.fixed=fixed;this.item={id:'sword-1',quantity:1,slot:0};this.visible=true;this.dragging=false;}
 begin(){this.dragging=true;this.visible=false;}
 drop(slot){if(!this.dragging)return;this.dragging=false;if(slot===0||slot===1){this.item.slot=slot;this.visible=true;}else if(this.fixed)this.visible=true;}
 reopen(){this.visible=true;this.dragging=false;}
}
export function make(kind,fixed){return kind==='W-481'?new Reward(fixed):kind==='W-484'?new Battle(fixed):new Inventory(fixed);}
export const cases={
 'W-481':{title:'Reward panel after reopening',steps:['Open panel','Claim success','Close panel','Reopen panel','Attempt claim again'],run(m,n){if(n===0)m.open();if(n===1)m.claim(true);if(n===2)m.close();if(n===3)m.open();if(n===4)m.claim(true);}},
 'W-484':{title:'One confirmation across reconnect',steps:['Start battle: no history','Receive attack-1','Disconnect; retain state','Reconnect: receive attack-1 again'],run(m,n){if(n===1||n===3)m.receive('attack-1');}},
 'W-485':{title:'Cancelled inventory drag',steps:['Open inventory: sword-1 in slot 0','Begin drag','Release over invalid area','Inspect original slot','Close and reopen inventory'],run(m,n){if(n===1)m.begin();if(n===2)m.drop(-1);if(n===4)m.reopen();}}
};
