from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os
os.chdir(Path(__file__).parent/'public')
class Handler(SimpleHTTPRequestHandler):
 def do_POST(self):
  allowed={f'{i}-{v}.webm' for i in ['W-481','W-484','W-485'] for v in ['faulty','fixed']}|{'environment.json'}
  name=self.path.removeprefix('/recordings/');length=int(self.headers.get('Content-Length','0'))
  if not self.path.startswith('/recordings/') or name not in allowed or length>15000000:self.send_error(400);return
  dest=Path('recordings');dest.mkdir(exist_ok=True);(dest/name).write_bytes(self.rfile.read(length));self.send_response(200);self.end_headers();self.wfile.write(b'OK')
ThreadingHTTPServer(('127.0.0.1',8915),Handler).serve_forever()
