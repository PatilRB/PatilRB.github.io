# Synthetic QA examples

Run node check.mjs from this folder. Start python3 serve.py, then open http://127.0.0.1:8915/. The six recordings are scripted captures of the actual browser fixture canvas, not production game footage. Results are written to evidence/qa-tests.json.
