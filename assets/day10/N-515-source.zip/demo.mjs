import * as T from 'three';import {ThreeVfxRenderer} from 'nixie-fx/three';import {seedEffect} from './seeds.mjs';
const renderer=new T.WebGLRenderer({antialias:true});renderer.setSize(960,520);document.querySelector('#view').append(renderer.domElement);
const scene=new T.Scene();scene.background=new T.Color('#111f33');const camera=new T.OrthographicCamera(-3.2,3.2,1.73,-1.73,.1,20);camera.position.z=10;
const line=new T.Line(new T.BufferGeometry().setFromPoints([new T.Vector3(0,-1.5,0),new T.Vector3(0,1.5,0)]),new T.LineBasicMaterial({color:0x405a77}));scene.add(line);
const vfx=new ThreeVfxRenderer({scene,camera});let left,right,different=false,paused=true;
function setup(isDifferent){different=isDifferent;if(left)vfx.removeEffect(left);if(right)vfx.removeEffect(right);left=vfx.createEffect(seedEffect(),{seed:2020,position:[-1.5,0,0]});right=vfx.createEffect(seedEffect(),{seed:different?2021:2020,position:[1.5,0,0]});for(let i=0;i<12;i++)vfx.update(1/60);left.pause();right.pause();paused=true;document.querySelector('#labels').textContent=`Left: seed 2020 | Right: seed ${different?2021:2020} | fixed sample 0.20 s`;}
document.querySelector('#same').onclick=()=>setup(false);document.querySelector('#different').onclick=()=>setup(true);
document.querySelector('#replay').onclick=()=>{left.restart();right.restart();paused=false;};
let last=0;renderer.setAnimationLoop(ms=>{const dt=last?Math.min((ms-last)/1000,.05):0;last=ms;if(!paused)vfx.update(dt);renderer.render(scene,camera);document.querySelector('#status').textContent=`live ${vfx.stats.activeParticles} | visible ${vfx.stats.visibleParticles} | unsupported ${vfx.stats.unsupportedFeatures.length}`;});setup(false);
