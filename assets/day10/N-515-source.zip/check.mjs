import assert from 'node:assert/strict';import {writeFileSync} from 'node:fs';import * as T from 'three';import {ThreeVfxRenderer} from 'nixie-fx/three';import {seedEffect} from './seeds.mjs';
const effect=seedEffect();
function sample(seed){const scene=new T.Scene(),camera=new T.OrthographicCamera(-2,2,2,-2,.1,20);camera.position.z=10;camera.updateMatrixWorld(true);const vfx=new ThreeVfxRenderer({scene,camera,captureDebugTransforms:true});
const options=seed===undefined?{}:{seed};const fx=vfx.createEffect(effect,options);for(let i=0;i<12;i++)vfx.update(1/60);
const snapshot=()=>fx.getParticleDebugTransforms().map(p=>({i:p.particleIndex,position:p.position})).sort((a,b)=>a.i-b.i);
const result={particles:snapshot(),unsupported:vfx.stats.unsupportedFeatures};fx.restart();for(let i=0;i<12;i++)vfx.update(1/60);assert.deepEqual(snapshot(),result.particles);vfx.destroy();return result;}
const a=sample(2020),b=sample(2020),c=sample(2021),u=sample(),v=sample();
assert.equal(a.particles.length,24);assert.deepEqual(a,b);assert.deepEqual(u,v);assert.notDeepEqual(a.particles,c.particles);
const changed=a.particles.filter((p,i)=>JSON.stringify(p.position)!==JSON.stringify(c.particles[i].position)).length;
assert.equal(a.unsupported.length,0);assert.equal(effect.support.backends.three3d.blockers.length,0);assert.equal(effect.support.backends.pixi2d.blockers.length,0);
const result={versions:{nixieFx:'0.1.20',three:'0.185.1'},sampleTimeSeconds:.2,stepSeconds:1/60,particles:24,sameSeedEqual:true,restartEqual:true,omittedSeedRepeats:true,differentSeedChangedParticles:changed,support:effect.support,unsupported:a.unsupported,limits:'Three adapter position check only; no Pixi rendering, cross-platform screenshot equality or GPU benchmark.'};
writeFileSync('./evidence/N-515-seeds.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
