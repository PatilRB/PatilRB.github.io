# Three.js companion fixture

Run npm ci, npm run check, then npm run build from this folder. Serve public/ over HTTP, for example python3 -m http.server 8000 --directory public. Test evidence is in evidence/. Pinned dependencies and license notices are included. PixiJS visual parity and device performance are outside this fixture.
