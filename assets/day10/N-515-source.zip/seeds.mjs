import {createDefaultParticleEffect,createConstantParticleScalar as s} from 'nixie-fx';
import {compileVfxExport,loadVfxExportBundle} from 'nixie-fx/export';
export function seedEffect(){
 const p=createDefaultParticleEffect('player-burst','Player seed comparison');p.targetProfile='portable';p.timeline.duration=.8;p.timeline.loop.enabled=false;
 const e=p.emitters[0];e.id='burst';e.duration=.8;e.loop=false;e.maxParticles=24;
 e.spawn.shape='point';e.spawn.simulationSpace='world';e.spawn.rate=0;e.spawn.rateValue=s(0);
 e.spawn.bursts=[{time:0,count:24,cycles:1,interval:0,probability:1}];
 e.initializeParticle.lifetime=s(.6);e.initializeParticle.velocity.mode='vector';e.initializeParticle.velocity.min=[-2,-2,0];e.initializeParticle.velocity.max=[2,2,0];
 e.initializeParticle.size=s(.055);e.billboard.sizeStart=.055;e.billboard.sizeEnd=.055;e.billboard.sizeValue=s(.055);
 e.render.shading='unlit';e.render.blend='alpha';e.render.depthTest=false;e.render.depthWrite=false;
 e.initializeParticle.color.color=[.4,.8,1,.9];e.modules.color=true;e.color.gradient.colorStops=[{position:0,color:[.4,.8,1]},{position:1,color:[.4,.8,1]}];e.color.gradient.alphaStops=[{position:0,alpha:.9},{position:1,alpha:0}];
 const c=compileVfxExport([{effect:p,effectPath:'effects/player-burst.json'}]);
 return loadVfxExportBundle({manifest:c.manifest,effectsByPath:Object.fromEntries(c.effects.map(x=>[x.path,x.effect])),assetPaths:[]},{requiredBackend:'three3d',requireEveryAsset:true}).effectsById.get('player-burst');
}
